CREATE TABLE order_book (
    id BIGSERIAL PRIMARY KEY,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL,
    price TEXT NOT NULL,
    currency TEXT NOT NULL,
    ticker TEXT NOT NULL,
    bid_volume TEXT,
    ask_volume TEXT,
    source TEXT
);